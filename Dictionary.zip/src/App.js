import './App.css';
import { Front } from './scripts/FrontPage';

function App() {
  return (
    <>
      <Front></Front>
    </>
  );
}

export default App;
