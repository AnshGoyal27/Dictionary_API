import axios from "axios";

export function Search(searchvalue,fn){
    let def=[];
    const url=(process.env.REACT_APP_API_URL)+(searchvalue)+(process.env.REACT_APP_API_URL_LATTER);
    const promise=axios.get(url);
    promise.then(result=>{
        result.data.forEach(element=>{
            if(element.text){
                def.push(element.text);
            }
        })
        fn(def);
    })
    .catch(err=>{
        console.log(err);
    })
    
}