import { useState } from "react"
import { SearchBox } from "./SearchBox"

export const Front=()=>{
    const [definition,setDef]=useState([]);
    
    function called(val){
        setDef(val);
    }

    return(
    <div>
        <h1>Dictionary</h1>
        <SearchBox calling={called}></SearchBox>
        {definition.map(ele=><h4>{ele}</h4>)}
    </div>
    )
}