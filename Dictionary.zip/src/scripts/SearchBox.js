import { Search } from "./Api_Client";
export const SearchBox=({calling})=>{
    const btn=()=>{
        Search(document.getElementById('input').value,calling);
    }
    return(
        <div>
            <input type="text" placeholder="Enter to Search" id="input"></input>
            <button onClick={btn}>Submit</button>
        </div>
    )
}